#ifndef CONSLOG_H_H
#define CONSLOG_H_H

extern int conslog_agent_connect(char* ip);
extern int conslog_agent_record(char* barcode, char* ok_fail);
extern int conslog_agent_stop();

extern int conslog_server_ip(char* ip);

#endif
