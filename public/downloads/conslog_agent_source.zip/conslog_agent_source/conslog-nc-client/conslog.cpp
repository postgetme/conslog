#include "conslog.h"
#include <stdio.h>
#include <windows.h>
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")

static char* VER = "V1.0";
static char* DATE = "20150204";

static int DEBUG = 0;

static int CONSLOG_AGENT_PORT = 5500;

static char* CONSLOG_SERVER_IP = "10.5.68.79";

static SOCKET g_socket_agent;
static FILE* g_pfile_temp = NULL;
static FILE* g_pfile_conslog_agent_log = NULL;
static HANDLE g_thread_conslog_agent_recv = NULL;
static char* g_board_ip;

static void conslog_agent_log(char* fmt, ...)
{
    va_list argptr;
    static char s[2048];
    int len = 0;

    va_start(argptr, fmt);
    len = _vsnprintf(s, sizeof(s), fmt, argptr);
    va_end(argptr);

    if(DEBUG)
    {
        printf(s);
    }

    if(!g_pfile_conslog_agent_log)
    {
        return;
    }

    fwrite(s, 1, len, g_pfile_conslog_agent_log);
    fflush(g_pfile_conslog_agent_log);
}

//���ӵ���nc����������nc��������������浽�����ļ�
static DWORD WINAPI conslog_agent_recv(LPVOID lpParameter)
{
    g_pfile_temp = fopen("conslog/temp.txt", "w");
    if(!g_pfile_temp)
    {
        conslog_agent_log("open conslog/temp.txt fail.\n");
        return -1;
    }

    WSADATA wsaData;
    if(WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        return -2;
    }

    SOCKET g_socket_agent = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    struct hostent *host;
    host = gethostbyname(g_board_ip);
    SOCKADDR_IN sock_addr;
    sock_addr.sin_port = htons(CONSLOG_AGENT_PORT);
    sock_addr.sin_family = AF_INET;
    sock_addr.sin_addr.s_addr = *((unsigned long*)host->h_addr);

    char recv_buf[64] = {0};
    int recv_len = 0;
    
    conslog_agent_log("connecting to board %s...\n", g_board_ip);
    while(1)
    {
        if(connect(g_socket_agent, (SOCKADDR*)(&sock_addr), sizeof(sock_addr)) != 0)
        {
            Sleep(100);
            continue;
        }
        else
        {
            conslog_agent_log("connected.\n");

            while(1)
            {    
                if((recv_len = recv(g_socket_agent, recv_buf, sizeof(recv_buf) - 1, 0)) > 0)
                {
                    if(DEBUG)
                    {
                        recv_buf[recv_len] = 0;
                        printf("%s", recv_buf);
                    }

                    fwrite(recv_buf, 1, recv_len, g_pfile_temp);
                    fflush(g_pfile_temp);
                }
                else if(recv_len == 0)
                {
                    conslog_agent_log("disconnected.\n");
                    break;
                }
                else
                {
                    //conslog_agent_log("recv error.\n");
                    conslog_agent_log("disconnected.\n");
                    break;
                }
            }

            //�������Ͽ������³�ʼ��socket��׼������
            closesocket(g_socket_agent);
            SOCKET g_socket_agent = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            
            //��������׷�ӵ���ʽд�����ļ�
            fclose(g_pfile_temp);
            g_pfile_temp = fopen("conslog/temp.txt", "a");
            if(!g_pfile_temp)
            {
                conslog_agent_log("open conslog/temp.txt fail.\n");
                return -3;
            }
        }
    }

    return 0;
}

int conslog_agent_connect(char* ip)
{    
    //����conslog agent��־�ļ�
    CreateDirectory("conslog", NULL);
    g_pfile_conslog_agent_log = fopen("conslog/conslog_agent.log", "w");
    if(!g_pfile_conslog_agent_log)
    {
        if(DEBUG)
        {
            printf("open conslog/conslog_agent.log fail.\n");
        }

        return -1;
    }

    conslog_agent_log("conslog agent %s %s\n", VER, DATE);
    conslog_agent_log("conslog_agent_connect()\n");

    g_board_ip = ip;

    //�����߳̽��յ�����־
    g_thread_conslog_agent_recv = CreateThread(NULL, 0, conslog_agent_recv, NULL, 0, NULL); 
    if(!g_thread_conslog_agent_recv)
    {
        conslog_agent_log("create conslog agent recv thread fail.");

        return -2;
    }

    //�����̷߳��ͱ�����־��conslog server

    //�����߳��������̣�

    return 0;
}

//�������ļ��ϴ�����־���������������Ϸ�����ʱ�����ڱ���
int conslog_agent_record(char* barcode, char* pass_fail)
{
    //ͨ���ж�conslog agent��־�ļ��Ƿ��, ���ж�conslog_agent_connect()�Ƿ��ѵ��á��豣֤�ȵ���connect�ٵ���record��
    if(g_pfile_conslog_agent_log == NULL)
    {
        if(DEBUG)
        {
            printf("conslog agent haven't started!\n");
        }

        return -1;
    }

    conslog_agent_log("conslog_agent_record()\n");

    //�رս����߳�
    if(g_thread_conslog_agent_recv)
    {
        CloseHandle(g_thread_conslog_agent_recv);
    }
    
    //�رս����߳��д򿪵Ļ����ļ�
    if(g_pfile_temp)
    {
        fclose(g_pfile_temp);
    }

    //�򿪻����ļ�����ȡ�����ļ�����
    g_pfile_temp = fopen("conslog/temp.txt", "rb");
    if(!g_pfile_temp)
    {
        conslog_agent_log("open conslog/temp.txt fail!\n");
        return -2;
    }
    fseek(g_pfile_temp, 0, SEEK_END);
    int temp_file_size = ftell(g_pfile_temp);
    if(temp_file_size == 0)
    {
        conslog_agent_log("conslog/temp.txt is empty, exit.\n");
        return -3;
    }
    fseek(g_pfile_temp, 0, SEEK_SET);
    char* temp_file_buf = new char[temp_file_size];
    fread(temp_file_buf, temp_file_size, 1, g_pfile_temp);
    fclose(g_pfile_temp);

    //����conslog server
    WSADATA wsaData;
    if(WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        return -4;
    }

    SOCKET socket_conslog_server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    struct hostent *host;
    host = gethostbyname(CONSLOG_SERVER_IP);
    SOCKADDR_IN sock_addr;
    sock_addr.sin_port = htons(80);
    sock_addr.sin_family = AF_INET;
    sock_addr.sin_addr.s_addr = *((unsigned long*)host->h_addr);

    if(connect(socket_conslog_server, (SOCKADDR*)(&sock_addr), sizeof(sock_addr)) != 0)
    {
        conslog_agent_log("connect to conslog server %s fail.\n", CONSLOG_SERVER_IP);
        closesocket(socket_conslog_server);

        //�����ڱ���
        char local_log_name[512] = {0};
        sprintf(local_log_name, "conslog/%s_%s.log", barcode, pass_fail);
        FILE* pfile_local_log = fopen(local_log_name, "wb");
        if(!pfile_local_log)
        {
            conslog_agent_log("open %s fail, record fail.\n", local_log_name);
            return -5;
        }
        fwrite(temp_file_buf, 1, temp_file_size, pfile_local_log);
        fclose(pfile_local_log);
        //�ڴ��ͷ�
        delete[] temp_file_buf;

        conslog_agent_log("%s_%s.log recorded in local.\n", barcode, pass_fail);
        return 1;
    }
    else
    {
        conslog_agent_log("connected to conslog server %s.\n", CONSLOG_SERVER_IP);

        //��ʽ��http head
        char header[1024] = {0};
        sprintf(header,
                "POST /%s_%s/log HTTP/1.1\r\n"
                "Host: localhost\r\n"
                "Content-Type: text/plain\r\n"
                "Content-Length: %d\r\n"
                "\r\n", 
                barcode, pass_fail, temp_file_size);

        //����http head
        send(socket_conslog_server, header, strlen(header), 0);
        //�����ļ���conslog server
        send(socket_conslog_server, temp_file_buf, temp_file_size, 0);
        //�ڴ��ͷ�
        delete[] temp_file_buf;

        //�˴������ж�HTTP����
        /*
        char recv_buf[1024] = {0};
        int nDataLength;    
        while(1)
        {
            while((nDataLength = recv(socket_conslog_server, recv_buf, 100000, 0)) > 0)
            {        
                printf("***%d***\n", nDataLength);
                printf("%s", recv_buf);
                break;
            }
        }
        */

        closesocket(socket_conslog_server);
        conslog_agent_log("%s_%s.log recorded in conslog server.\n", barcode, pass_fail);
        return 2;
    }
}

int conslog_agent_stop()
{
    conslog_agent_log("conslog_agent_stop()\n");

    if(g_pfile_conslog_agent_log)
    {
        fclose(g_pfile_conslog_agent_log);
    }

    if(g_thread_conslog_agent_recv)
    {
        CloseHandle(g_thread_conslog_agent_recv);
    }

    if(g_pfile_temp)
    {
        fclose(g_pfile_temp);
    }

    closesocket(g_socket_agent);
    WSACleanup();

    return 0;
}

int conslog_server_ip(char* ip)
{
    CONSLOG_SERVER_IP = ip;

    return 0;
}

int conslog_agent_debug(int on_off)
{
    DEBUG = on_off;

    return 0;
}
